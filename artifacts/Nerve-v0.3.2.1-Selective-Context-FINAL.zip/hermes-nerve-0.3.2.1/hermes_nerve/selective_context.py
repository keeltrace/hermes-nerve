"""Provider-neutral selective context admission for Nerve v0.3.2.1."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
import hashlib, json, math, re, threading, time
from typing import Any, Callable, Iterable, Mapping, Sequence

_WORD=re.compile(r"[A-Za-z0-9_./:-]+")
_VALID_KINDS={"memory","tool","skill"}
_VALID_MODES={"off","shadow","apply"}

class AdmissionAction(str,Enum):
    PIN="pin"; ADMIT="admit"; DEFER="defer"; SUPPRESS="suppress"

@dataclass(frozen=True)
class ContextCandidate:
    kind:str
    candidate_id:str
    source:str=""
    title:str=""
    summary:str=""
    estimated_tokens:int=0
    metadata:Mapping[str,Any]=field(default_factory=dict)
    provider_score:float|None=None
    trust:float|None=None
    recency:float|None=None
    mandatory:bool=False
    def normalized(self):
        kind=str(self.kind or "").strip().lower()
        if kind not in _VALID_KINDS: raise ValueError(f"unknown context kind: {kind!r}")
        cid=str(self.candidate_id or "").strip()
        if not cid: raise ValueError("candidate_id is required")
        return ContextCandidate(kind,cid,str(self.source or "")[:160],str(self.title or "")[:500],
            str(self.summary or "")[:4000],max(0,int(self.estimated_tokens or 0)),dict(self.metadata or {}),
            _prob(self.provider_score),_prob(self.trust),_prob(self.recency),bool(self.mandatory))

@dataclass(frozen=True)
class AdmissionDecision:
    candidate_id:str
    action:AdmissionAction
    reason_code:str
    confidence:float
    score:float
    lease_id:str=""

@dataclass(frozen=True)
class TaskFingerprint:
    digest:str
    tokens:tuple[str,...]
    project:str=""
    repository:str=""

@dataclass
class AdmissionLease:
    lease_id:str
    task_fingerprint:str
    kind:str
    candidate_ids:tuple[str,...]
    created_at:float
    touched_at:float

@dataclass
class SurfaceConfig:
    mode:str="shadow"
    max_candidates:int=48
    max_admitted:int=8
    min_score:float=.28

@dataclass
class SelectiveContextConfig:
    enabled:bool=True
    memory:SurfaceConfig=field(default_factory=lambda:SurfaceConfig("shadow",24,8,.28))
    tools:SurfaceConfig=field(default_factory=lambda:SurfaceConfig("shadow",128,16,.18))
    skills:SurfaceConfig=field(default_factory=lambda:SurfaceConfig("shadow",128,5,.22))
    lease_enabled:bool=True
    lease_max_age_seconds:int=3600
    semantic_enabled:bool=False

def _prob(value):
    if value is None or value=="": return None
    try: return max(0.,min(1.,float(value)))
    except (TypeError,ValueError): return None

def _terms(value):
    return {m.group(0).lower() for m in _WORD.finditer(str(value or "")) if len(m.group(0))>1}

def estimate_tokens(text:str)->int:
    return max(1,math.ceil(len(str(text or ""))/4)) if text else 0

def task_fingerprint(user_message:str,*,project:str="",repository:str="",recent_topic:str="")->TaskFingerprint:
    terms=sorted(_terms(user_message)|_terms(recent_topic))
    stable={"tokens":terms,"project":str(project or "").strip().lower(),"repository":str(repository or "").strip().lower()}
    digest=hashlib.sha256(json.dumps(stable,sort_keys=True,separators=(",",":")).encode()).hexdigest()[:24]
    return TaskFingerprint(digest,tuple(terms),stable["project"],stable["repository"])

class LeaseStore:
    def __init__(self):
        self._lock=threading.RLock(); self._leases={}
    def get(self,fingerprint,kind,*,max_age_seconds):
        now=time.time()
        with self._lock:
            lease=self._leases.get((fingerprint,kind))
            if not lease or now-lease.created_at>max(1,int(max_age_seconds)):
                self._leases.pop((fingerprint,kind),None); return None
            lease.touched_at=now; return lease
    def put(self,fingerprint,kind,candidate_ids):
        now=time.time(); payload=f"{fingerprint}:{kind}:{','.join(candidate_ids)}:{int(now)}"
        lease=AdmissionLease("nlease-"+hashlib.sha256(payload.encode()).hexdigest()[:20],fingerprint,kind,tuple(candidate_ids),now,now)
        with self._lock: self._leases[(fingerprint,kind)]=lease
        return lease
    def invalidate(self,*,fingerprint="",kind=""):
        with self._lock:
            keys=[k for k in self._leases if (not fingerprint or k[0]==fingerprint) and (not kind or k[1]==kind)]
            for k in keys:self._leases.pop(k,None)
            return len(keys)
    def count(self):
        with self._lock:return len(self._leases)

class ContextAdmissionController:
    def __init__(self,config=None):
        self.config=config or SelectiveContextConfig(); self.leases=LeaseStore(); self._lock=threading.RLock()
        self._metrics={k:0 for k in ("plans","candidates","admitted","deferred","suppressed","baseline_tokens","selected_tokens","gross_tokens_saved","semantic_calls","semantic_errors","fail_open","lease_hits")}
    def _surface(self,kind): return getattr(self.config, {"tool":"tools","skill":"skills"}.get(kind,kind))
    @staticmethod
    def _fallback_action(kind): return AdmissionAction.SUPPRESS if kind=="memory" else AdmissionAction.DEFER
    def plan(self,*,goal,candidates,kind,fingerprint=None,semantic_decider=None):
        kind=str(kind or "").strip().lower()
        if kind not in _VALID_KINDS: raise ValueError(f"unknown context kind: {kind}")
        surface=self._surface(kind); mode=surface.mode if surface.mode in _VALID_MODES else "shadow"
        raw=list(candidates); normalized=[]; seen=set(); baseline_tokens=0
        try:
            for item in raw[:max(1,int(surface.max_candidates))]:
                c=item if isinstance(item,ContextCandidate) else ContextCandidate(**dict(item))
                c=c.normalized(); baseline_tokens+=c.estimated_tokens
                if c.candidate_id in seen: continue
                seen.add(c.candidate_id); normalized.append(c)
        except Exception:
            with self._lock:self._metrics["fail_open"]+=1
            return self._fail_open(kind,mode,raw)
        if not self.config.enabled or mode=="off": return self._fail_open(kind,mode,normalized)

        fp=fingerprint or task_fingerprint(goal)
        lease=self.leases.get(fp.digest,kind,max_age_seconds=self.config.lease_max_age_seconds) if self.config.lease_enabled else None
        if lease and set(lease.candidate_ids).issubset(seen):
            hot=set(lease.candidate_ids)
            decisions=[AdmissionDecision(c.candidate_id,AdmissionAction.PIN if c.candidate_id in hot else self._fallback_action(kind),
                        "SESSION_PIN" if c.candidate_id in hot else "LEASE_DEFER",1.,1. if c.candidate_id in hot else 0.,
                        lease.lease_id if c.candidate_id in hot else "") for c in normalized]
            with self._lock:self._metrics["lease_hits"]+=1
            return self._result(kind,mode,normalized,decisions,baseline_tokens,fp)

        goal_terms=_terms(goal); decisions_by_id={}; scored=[]
        for c in normalized:
            if c.mandatory or bool(c.metadata.get("mandatory")):
                decisions_by_id[c.candidate_id]=AdmissionDecision(c.candidate_id,AdmissionAction.PIN,"MANDATORY",1.,1.); continue
            if bool(c.metadata.get("already_present")):
                decisions_by_id[c.candidate_id]=AdmissionDecision(c.candidate_id,AdmissionAction.SUPPRESS,"ALREADY_PRESENT",.99,0.); continue
            if bool(c.metadata.get("expired")) or c.metadata.get("status") in {"expired","superseded"}:
                decisions_by_id[c.candidate_id]=AdmissionDecision(c.candidate_id,AdmissionAction.SUPPRESS,"STALE",.98,0.); continue
            if bool(c.metadata.get("entity_mismatch")):
                decisions_by_id[c.candidate_id]=AdmissionDecision(c.candidate_id,AdmissionAction.SUPPRESS,"ENTITY_MISMATCH",.98,0.); continue
            c_terms=_terms(c.title)|_terms(c.summary)|_terms(c.metadata.get("keywords",""))
            overlap=len(goal_terms&c_terms)/max(1,len(goal_terms)) if goal_terms else 0.
            provider=c.provider_score if c.provider_score is not None else 0.
            trust=c.trust if c.trust is not None else .65
            recency=c.recency if c.recency is not None else .65
            penalty=min(.25,c.estimated_tokens/8000.)
            score=max(0.,min(1.,.56*overlap+.16*provider+.18*trust+.10*recency-penalty))
            if goal_terms and overlap==0. and provider<.55: score*=.20
            scored.append((score,c,"DIRECT_TASK_MATCH" if overlap else "LOW_RELEVANCE",max(overlap,provider,trust*.7)))
        scored.sort(key=lambda r:(-r[0],r[1].estimated_tokens,r[1].candidate_id))
        mandatory=sum(1 for d in decisions_by_id.values() if d.action==AdmissionAction.PIN)
        room=max(0,int(surface.max_admitted)-mandatory)
        selected=[r for r in scored if r[0]>=surface.min_score][:room]

        if self.config.semantic_enabled and semantic_decider and scored:
            try:
                ambiguous=[r[1] for r in scored[:min(24,len(scored))]]
                valid={c.candidate_id for c in ambiguous}
                ids=[x for x in dict.fromkeys(str(x) for x in semantic_decider(goal,ambiguous,room)) if x in valid][:room]
                if ids:
                    wanted=set(ids); selected=[r for r in scored if r[1].candidate_id in wanted]
                with self._lock:self._metrics["semantic_calls"]+=1
            except Exception:
                with self._lock:self._metrics["semantic_errors"]+=1

        chosen={r[1].candidate_id for r in selected}
        for score,c,reason,confidence in scored:
            decisions_by_id[c.candidate_id]=AdmissionDecision(c.candidate_id,
                AdmissionAction.ADMIT if c.candidate_id in chosen else self._fallback_action(kind),
                reason if c.candidate_id in chosen else ("TOKEN_BUDGET" if score>=surface.min_score else "TOPIC_MISMATCH"),
                confidence if c.candidate_id in chosen else max(.5,1.-score),score)
        decisions=[decisions_by_id[c.candidate_id] for c in normalized]
        hot=[d.candidate_id for d in decisions if d.action in {AdmissionAction.PIN,AdmissionAction.ADMIT}]
        if hot and self.config.lease_enabled:
            lease=self.leases.put(fp.digest,kind,hot)
            decisions=[AdmissionDecision(d.candidate_id,d.action,d.reason_code,d.confidence,d.score,lease.lease_id if d.candidate_id in hot else "") for d in decisions]
        return self._result(kind,mode,normalized,decisions,baseline_tokens,fp)

    def _fail_open(self,kind,mode,candidates):
        ids=[]; tokens=0
        for i,raw in enumerate(candidates):
            if isinstance(raw,ContextCandidate): cid,cost=raw.candidate_id,raw.estimated_tokens
            elif isinstance(raw,Mapping): cid,cost=str(raw.get("candidate_id") or raw.get("id") or f"candidate-{i}"),int(raw.get("estimated_tokens") or 0)
            else: cid,cost=f"candidate-{i}",0
            ids.append(cid);tokens+=max(0,cost)
        return {"schema":"hermes-nerve-selective-context/v1","kind":kind,"mode":mode,"fail_open":True,
            "decisions":[{**asdict(AdmissionDecision(x,AdmissionAction.ADMIT,"FAIL_OPEN",1.,1.)),"action":"admit"} for x in ids],
            "selected_ids":ids,"deferred_ids":[],"suppressed_ids":[],"effective_selected_ids":ids,
            "baseline_tokens":tokens,"selected_tokens":tokens,"effective_tokens":tokens,
            "gross_tokens_saved":0,"applied_tokens_saved":0,"admission_overhead_tokens":0,"net_tokens_saved":0}

    def _result(self,kind,mode,candidates,decisions,baseline_tokens,fp):
        by_id={c.candidate_id:c for c in candidates}
        selected=[d.candidate_id for d in decisions if d.action in {AdmissionAction.PIN,AdmissionAction.ADMIT}]
        deferred=[d.candidate_id for d in decisions if d.action==AdmissionAction.DEFER]
        suppressed=[d.candidate_id for d in decisions if d.action==AdmissionAction.SUPPRESS]
        selected_tokens=sum(by_id[x].estimated_tokens for x in selected if x in by_id); gross=max(0,baseline_tokens-selected_tokens)
        all_ids=[c.candidate_id for c in candidates]
        effective_selected=selected if mode=="apply" else all_ids
        effective_tokens=selected_tokens if mode=="apply" else baseline_tokens
        applied=max(0,baseline_tokens-effective_tokens)
        with self._lock:
            self._metrics["plans"]+=1;self._metrics["candidates"]+=len(candidates);self._metrics["admitted"]+=len(selected)
            self._metrics["deferred"]+=len(deferred);self._metrics["suppressed"]+=len(suppressed)
            self._metrics["baseline_tokens"]+=baseline_tokens;self._metrics["selected_tokens"]+=selected_tokens;self._metrics["gross_tokens_saved"]+=gross
        return {"schema":"hermes-nerve-selective-context/v1","kind":kind,"mode":mode,"fail_open":False,"task_fingerprint":fp.digest,
            "decisions":[{**asdict(d),"action":d.action.value} for d in decisions],"selected_ids":selected,"deferred_ids":deferred,
            "suppressed_ids":suppressed,"effective_selected_ids":effective_selected,
            "baseline_tokens":baseline_tokens,"selected_tokens":selected_tokens,"effective_tokens":effective_tokens,
            "gross_tokens_saved":gross,"applied_tokens_saved":applied,"admission_overhead_tokens":0,"net_tokens_saved":applied}

    def report(self):
        with self._lock: metrics=dict(self._metrics)
        base=int(metrics["baseline_tokens"]);gross=int(metrics["gross_tokens_saved"])
        return {"schema":"hermes-nerve-selective-context-stats/v1","enabled":bool(self.config.enabled),
            "modes":{"memory":self.config.memory.mode,"tools":self.config.tools.mode,"skills":self.config.skills.mode},
            "metrics":metrics,"lease_count":self.leases.count(),"gross_reduction_percent":round(100.*gross/base,3) if base else 0.,
            "semantic_provider_calls":int(metrics["semantic_calls"])}

def memory_candidate_from_experience(item):
    claim=dict(item.get("claim") or item);statement=str(claim.get("statement") or "");kind=str(claim.get("claim_type") or "")
    trust={"verified":1.,"disproven":.95,"observed":.75,"inferred":.5}.get(kind,.5)
    return ContextCandidate("memory",str(claim.get("claim_id") or item.get("candidate_id") or ""),"nerve_verified_experience",
        str(claim.get("subject") or ""),statement,int(claim.get("estimated_tokens") or estimate_tokens(statement)),
        {"status":str(claim.get("status") or "active"),"evidence_ids":list(claim.get("evidence_ids") or []),"claim_type":kind},
        _prob(item.get("score")),trust,None,bool(claim.get("mandatory")))

def tool_candidate(tool):
    fn=tool.get("function") if isinstance(tool.get("function"),Mapping) else tool
    name=str(fn.get("name") or tool.get("name") or "");desc=str(fn.get("description") or tool.get("description") or "")
    schema=json.dumps(tool,sort_keys=True,separators=(",",":"),default=str)
    return ContextCandidate("tool",name,str(tool.get("source") or "hermes"),name,desc,
        int(tool.get("estimated_tokens") or estimate_tokens(schema)),{"toolset":tool.get("toolset",""),"core":bool(tool.get("core"))},
        None,None,None,bool(tool.get("mandatory") or tool.get("core")))

def skill_candidate(skill):
    name=str(skill.get("name") or skill.get("id") or "");desc=str(skill.get("description") or "")
    return ContextCandidate("skill",name,str(skill.get("source") or "hermes"),name,desc,
        int(skill.get("estimated_tokens") or estimate_tokens(f"{name}: {desc}")),{"category":skill.get("category","")},
        None,None,None,bool(skill.get("mandatory")))

_default=ContextAdmissionController()

def configure(**kwargs):
    global _default
    _default=ContextAdmissionController(SelectiveContextConfig(
        enabled=bool(kwargs.get("enabled",True)),
        memory=SurfaceConfig(str(kwargs.get("memory_mode","shadow")).lower(),max(1,int(kwargs.get("memory_max_candidates",24))),max(0,int(kwargs.get("memory_max_admitted",8))),float(kwargs.get("memory_min_score",.28))),
        tools=SurfaceConfig(str(kwargs.get("tools_mode","shadow")).lower(),max(1,int(kwargs.get("tools_max_candidates",128))),max(0,int(kwargs.get("tools_max_admitted",16))),float(kwargs.get("tools_min_score",.18))),
        skills=SurfaceConfig(str(kwargs.get("skills_mode","shadow")).lower(),max(1,int(kwargs.get("skills_max_candidates",128))),max(0,int(kwargs.get("skills_max_admitted",5))),float(kwargs.get("skills_min_score",.22))),
        lease_enabled=bool(kwargs.get("lease_enabled",True)),lease_max_age_seconds=max(1,int(kwargs.get("lease_max_age_seconds",3600))),
        semantic_enabled=bool(kwargs.get("semantic_enabled",False))))

def plan_memory(goal,candidates,**kwargs): return _default.plan(goal=goal,candidates=candidates,kind="memory",**kwargs)
def plan_tools(goal,candidates,**kwargs): return _default.plan(goal=goal,candidates=candidates,kind="tool",**kwargs)
def plan_skills(goal,candidates,**kwargs): return _default.plan(goal=goal,candidates=candidates,kind="skill",**kwargs)
def report(): return _default.report()