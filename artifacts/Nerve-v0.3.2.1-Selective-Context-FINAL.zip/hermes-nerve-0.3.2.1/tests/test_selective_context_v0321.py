from __future__ import annotations
import unittest

from hermes_nerve.selective_context import (
    AdmissionAction, ContextAdmissionController, ContextCandidate,
    SelectiveContextConfig, SurfaceConfig, memory_candidate_from_experience,
    skill_candidate, task_fingerprint, tool_candidate,
)

class SelectiveContextV0321Tests(unittest.TestCase):
    def controller(self, kind="memory"):
        cfg=SelectiveContextConfig()
        setattr(cfg,kind,SurfaceConfig(mode="apply",max_candidates=20,max_admitted=2,min_score=.12))
        return ContextAdmissionController(cfg)

    def test_memory_selects_relevant_and_suppresses_irrelevant(self):
        c=self.controller("memory")
        r=c.plan(goal="review nerve release blockers",kind="memory",candidates=[
            ContextCandidate("memory","release","x","Nerve release policy","release blocker qualification",100,trust=1.0),
            ContextCandidate("memory","van","x","green van","vehicle maintenance",100,trust=.8),
            ContextCandidate("memory","duplicate","x","already here","release blocker",100,metadata={"already_present":True}),
        ])
        self.assertIn("release",r["selected_ids"]);self.assertIn("van",r["suppressed_ids"])
        self.assertIn("duplicate",r["suppressed_ids"]);self.assertGreater(r["net_tokens_saved"],0)

    def test_mandatory_never_suppressed_even_at_zero_budget(self):
        c=ContextAdmissionController(SelectiveContextConfig(memory=SurfaceConfig("apply",20,0,.99)))
        r=c.plan(goal="unrelated",kind="memory",candidates=[ContextCandidate("memory","policy",summary="mandatory policy",estimated_tokens=20,mandatory=True)])
        self.assertEqual(r["selected_ids"],["policy"]);self.assertEqual(r["decisions"][0]["action"],AdmissionAction.PIN.value)

    def test_tools_defer_instead_of_disappear(self):
        c=self.controller("tools")
        r=c.plan(goal="review github pull request",kind="tool",candidates=[
            ContextCandidate("tool","github_pr",summary="github pull request review",estimated_tokens=500,trust=1),
            ContextCandidate("tool","gmail_send",summary="send email",estimated_tokens=500,trust=1),
        ])
        self.assertIn("github_pr",r["selected_ids"]);self.assertIn("gmail_send",r["deferred_ids"])

    def test_skills_defer_instead_of_disappear(self):
        c=self.controller("skills")
        r=c.plan(goal="review python code",kind="skill",candidates=[
            ContextCandidate("skill","code-review",summary="review python code",estimated_tokens=30,trust=1),
            ContextCandidate("skill","travel",summary="plan a vacation",estimated_tokens=30,trust=1),
        ])
        self.assertIn("code-review",r["selected_ids"]);self.assertIn("travel",r["deferred_ids"])

    def test_lease_reuses_stable_working_set(self):
        c=self.controller("tools");fp=task_fingerprint("review github pr")
        items=[ContextCandidate("tool","github",summary="github pr review",estimated_tokens=10,trust=1),
               ContextCandidate("tool","mail",summary="email",estimated_tokens=10,trust=1)]
        a=c.plan(goal="review github pr",kind="tool",candidates=items,fingerprint=fp)
        b=c.plan(goal="review github pr",kind="tool",candidates=items,fingerprint=fp)
        self.assertEqual(a["selected_ids"],b["selected_ids"]);self.assertGreaterEqual(c.report()["metrics"]["lease_hits"],1)

    def test_shadow_mode_only_proposes_and_keeps_effective_context(self):
        c=ContextAdmissionController(SelectiveContextConfig(memory=SurfaceConfig("shadow",20,1,.1)))
        r=c.plan(goal="release",kind="memory",candidates=[
            ContextCandidate("memory","release",summary="release",estimated_tokens=100,trust=1),
            ContextCandidate("memory","other",summary="unrelated vehicle",estimated_tokens=100,trust=1),
        ])
        self.assertEqual(set(r["effective_selected_ids"]), {"release","other"})
        self.assertEqual(r["effective_tokens"], r["baseline_tokens"])
        self.assertEqual(r["applied_tokens_saved"], 0)
        self.assertGreater(r["gross_tokens_saved"], 0)

    def test_invalid_candidate_fails_open(self):
        c=self.controller("memory")
        r=c.plan(goal="x",kind="memory",candidates=[{"candidate_id":"x","kind":"bogus","estimated_tokens":50}])
        self.assertTrue(r["fail_open"]);self.assertEqual(r["selected_ids"],["x"]);self.assertEqual(r["net_tokens_saved"],0)

    def test_semantic_failure_falls_back_to_deterministic(self):
        cfg=SelectiveContextConfig(semantic_enabled=True,memory=SurfaceConfig("apply",20,2,.1));c=ContextAdmissionController(cfg)
        def explode(*args): raise RuntimeError("no provider")
        r=c.plan(goal="release",kind="memory",candidates=[ContextCandidate("memory","r",summary="release",estimated_tokens=10,trust=1)],semantic_decider=explode)
        self.assertIn("r",r["selected_ids"]);self.assertEqual(c.report()["metrics"]["semantic_errors"],1)

    def test_experience_adapter_preserves_verification_trust(self):
        x=memory_candidate_from_experience({"score":.8,"claim":{"claim_id":"c1","subject":"release","statement":"tests passed","claim_type":"verified","evidence_ids":["e1"],"status":"active"}})
        self.assertEqual(x.kind,"memory");self.assertEqual(x.trust,1.0);self.assertGreater(x.estimated_tokens,0)

    def test_tool_and_skill_token_estimates_are_nonzero(self):
        self.assertGreater(tool_candidate({"function":{"name":"x","description":"do x","parameters":{"type":"object"}}}).estimated_tokens,0)
        self.assertGreater(skill_candidate({"name":"review","description":"review code"}).estimated_tokens,0)

    def test_task_fingerprint_is_stable_to_word_order(self):
        self.assertEqual(task_fingerprint("review nerve PR").digest,task_fingerprint("nerve PR review").digest)
        self.assertNotEqual(task_fingerprint("review nerve PR").digest,task_fingerprint("check calendar").digest)

    def test_report_accounts_for_gross_savings(self):
        c=self.controller("memory")
        c.plan(goal="alpha",kind="memory",candidates=[ContextCandidate("memory","a",summary="alpha",estimated_tokens=100,trust=1),ContextCandidate("memory","b",summary="zebra",estimated_tokens=100,trust=1)])
        r=c.report();self.assertEqual(r["schema"],"hermes-nerve-selective-context-stats/v1")
        self.assertGreater(r["metrics"]["gross_tokens_saved"],0);self.assertEqual(r["semantic_provider_calls"],0)

if __name__=="__main__": unittest.main()
